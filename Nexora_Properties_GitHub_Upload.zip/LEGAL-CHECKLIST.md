# LEGAL / BUSINESS CHECKLIST

Before public launch:
- Privacy Policy
- Terms & Conditions
- Cookie/analytics notice where required
- Property listing authorization terms
- Owner/agent agreement
- Lead/contact consent language
- Clear statement that Nexora is not the buyer/seller unless it actually is
- Jurisdiction-specific real-estate licensing review
- Written broker/partner agreements for any referral/compensation arrangement
- Tax/accounting setup for the business

Do not promise a fixed commission from every sale until the applicable law and partner agreement have been checked.
