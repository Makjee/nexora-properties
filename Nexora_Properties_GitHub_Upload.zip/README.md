# NEXORA PROPERTIES — LIVE DEPLOYMENT PACKAGE

Brand: Nexora Properties
WhatsApp: +92 302 9413381
Email: makjee0@gmail.com
Target market: USA + Europe

## Included
- Node.js/Express website
- Public property marketplace
- Owner/agent listing submission with authorization checkbox
- Buyer lead capture
- Secure admin login using environment credentials + signed HttpOnly session cookie
- Admin property approval, lead status and deal/compensation tracker
- robots.txt + dynamic sitemap.xml
- Render Blueprint (`render.yaml`)
- Cloudflare and Google setup guides

## Run locally
1. Install Node.js 20+.
2. Copy `.env.example` to `.env` and set a strong ADMIN_PASSWORD and SESSION_SECRET.
3. `npm install`
4. `npm start`
5. Open http://localhost:3000
6. Admin: http://localhost:3000/admin

## Render
Use the included `render.yaml` or create a Node Web Service from GitHub.
Build: `npm install`
Start: `npm start`
Health: `/health`

IMPORTANT: SQLite on a cloud service needs persistent storage to retain data. For a serious production launch, migrate the database to PostgreSQL and store property images in object storage (Cloudinary/S3/R2/etc.). This package intentionally does not contain third-party account credentials.

## Before real listings
Only publish properties you are authorized to market. Do not scrape/copy third-party listings without permission. Real-estate licensing/referral/commission rules vary by jurisdiction; use written agreements and local legal/broker review before accepting compensation.
