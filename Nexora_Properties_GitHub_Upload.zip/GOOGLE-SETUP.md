# GOOGLE SEARCH SETUP

After the domain works over HTTPS:

1. Open Google Search Console.
2. Add a Domain property for `nexoraproperties.com`.
3. Verify ownership using the DNS TXT record Google provides.
4. Open Sitemaps and submit:
   `https://nexoraproperties.com/sitemap.xml`
5. Use URL Inspection for the homepage and important property pages and request indexing.
6. Check Pages/Indexing reports over time.

Indexing and ranking are not guaranteed or immediate. Do not submit `/admin` as a public page.
