# CLOUDFLARE DNS — NEXORA PROPERTIES

Do NOT invent an IP address.

1. Deploy the app to Render first.
2. In Render, add custom domains:
   - nexoraproperties.com
   - www.nexoraproperties.com
3. Render will display the exact DNS target(s) for your service.
4. In Cloudflare DNS, add exactly those records.
5. For the web CNAME record, Cloudflare proxy can normally be enabled after the Render domain is working. If Render asks you to use DNS-only during verification, follow Render's current instruction.
6. Keep mail records DNS-only.
7. Verify both the root and www domain.

Because Render's target can change by service/account, this guide intentionally does not hard-code a fake CNAME or IP.
